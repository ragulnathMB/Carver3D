﻿#include "VulkanContext.hpp"
#include <iostream>
#include "ImageProcessor.hpp"
int main() {
	std::cout << "*** Welcome to Carver3D : 2D Image to 3D Model Converter Pipeline by RN ***" <<std:: endl;
	std::cout << "=============================================================" << std::endl;
    std::cout << "Commands for interacting with 3D spawned object :" << std::endl;
    std::cout << "W : to Zoom in" << std::endl;
	std::cout << "S : to Zoom out" << std::endl;
	std::cout << "Up Arrow : to Rotate Up" << std::endl;
	std::cout << "Down Arrow : to Rotate Down" << std::endl;
	std::cout << "Left Arrow : to Rotate Left" << std::endl;
	std::cout << "Right Arrow : to Rotate Right" << std::endl;
	std::cout << "I : to Translate Y Positive" << std::endl;
	std::cout << "K : to Translate Y Negative" << std::endl;
	std::cout << "J : to Translate X Negative" << std::endl;
	std::cout << "L : to Translate X Positive" << std::endl;
	std::cout << "============================================================" << std::endl;
    std::cout<<std::endl;
    std::cout << "Enter the Number view images: (e.g Front View,Side View,Top View i.e 3)";
	int numberOfImages;
    std::cin >> numberOfImages;
	ImageProcessor* imageProcessor = new ImageProcessor();
    imageProcessor->setNumberOfImages(numberOfImages);
    imageProcessor->userInput();
	imageProcessor->processImages();
	std::cout<<"hello"<<std::endl;
	float BigCuboidLength = imageProcessor->getImageLength();
	float BigCuboidWidth = imageProcessor->getImageWidth();
	std::cout << "Big Cuboid Length: " << BigCuboidLength << ", Width: " << BigCuboidWidth << std::endl;


    try {
        VulkanContext app(800, 600, "Silhouette Carving 3D Viewer",imageProcessor);
        app.run();
    }
    catch (const std::exception& e) {
        std::cerr << "Fatal Error: " << e.what() << std::endl;
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
