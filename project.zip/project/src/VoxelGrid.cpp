﻿#include "VoxelGrid.hpp"
#include <opencv2/imgproc.hpp>
#include <algorithm>
#include<iostream>
// Constructor
VoxelGrid::VoxelGrid(float h, float w,float d)
    : height(h), width(w), depth(d) {
    voxelGrid.resize(height, std::vector<std::vector<float>>(width, std::vector<float>(depth, 1.0f)));
}

// Destructor
VoxelGrid::~VoxelGrid() {
    // No dynamic memory to free manually, handled by vector destructors
}
#include <vector>
#include <cmath>

// 1. Helper: 3D Gaussian blur
void gaussianSmooth3D(std::vector<std::vector<std::vector<float>>>& grid, float sigma = 1.0f) {
    int kernelRadius = static_cast<int>(std::ceil(3 * sigma));
    int size = 2 * kernelRadius + 1;
    std::vector<float> kernel(size);
    float sum = 0.0f;

    // Create 1D Gaussian kernel
    for (int i = -kernelRadius; i <= kernelRadius; ++i) {
        float value = std::exp(-(i * i) / (2 * sigma * sigma));
        kernel[i + kernelRadius] = value;
        sum += value;
    }
    for (float& k : kernel) k /= sum;

    int H = grid.size(), W = grid[0].size(), D = grid[0][0].size();
    auto temp = grid;

    // Smooth in X
    for (int y = 0; y < H; ++y) {
        for (int z = 0; z < D; ++z) {
            for (int x = 0; x < W; ++x) {
                float smoothed = 0.0f;
                for (int k = -kernelRadius; k <= kernelRadius; ++k) {
                    int xi = std::clamp(x + k, 0, W - 1);
                    smoothed += grid[y][xi][z] * kernel[k + kernelRadius];
                }
                temp[y][x][z] = smoothed;
            }
        }
    }

    // Smooth in Y
    grid = temp;
    for (int x = 0; x < W; ++x) {
        for (int z = 0; z < D; ++z) {
            for (int y = 0; y < H; ++y) {
                float smoothed = 0.0f;
                for (int k = -kernelRadius; k <= kernelRadius; ++k) {
                    int yi = std::clamp(y + k, 0, H - 1);
                    smoothed += temp[yi][x][z] * kernel[k + kernelRadius];
                }
                grid[y][x][z] = smoothed;
            }
        }
    }

    // Smooth in Z
    temp = grid;
    for (int x = 0; x < W; ++x) {
        for (int y = 0; y < H; ++y) {
            for (int z = 0; z < D; ++z) {
                float smoothed = 0.0f;
                for (int k = -kernelRadius; k <= kernelRadius; ++k) {
                    int zi = std::clamp(z + k, 0, D - 1);
                    smoothed += grid[y][x][zi] * kernel[k + kernelRadius];
                }
                temp[y][x][z] = smoothed;
            }
        }
    }

    grid = temp; // Final smoothed grid
}

// Set voxel values based on front, side, and top views
void VoxelGrid::setVoxel(const cv::Mat& frontView, const cv::Mat& sideView, const cv::Mat& topView) {
    // Resize masks to voxel grid resolution
    cv::Mat frontResized, sideResized, topResized;
    cv::resize(frontView, frontResized, cv::Size(width, height));  // XY
    cv::resize(sideView, sideResized, cv::Size(depth, height));    // YZ
    cv::resize(topView, topResized, cv::Size(width, depth));       // ZX

    frontResized.convertTo(frontResized, CV_32FC1);
    sideResized.convertTo(sideResized, CV_32FC1);
    topResized.convertTo(topResized, CV_32FC1);

    // Fill voxel grid from projections
    for (unsigned int y = 0; y < height; ++y) {
        for (unsigned int x = 0; x < width; ++x) {
            for (unsigned int z = 0; z < depth; ++z) {
                float frontVal = frontResized.at<float>(y, x);
                float sideVal = sideResized.at<float>(x,z);
                float topVal = topResized.at<float>(y,z);
                voxelGrid[y][x][z] = std::min({frontVal,topVal});
            }
        }
    }

    // 🔥 Apply Gaussian smoothing to smooth the surface
    gaussianSmooth3D(voxelGrid, 1.0f); // You can try sigma = 1.0 to 2.0 for stronger blur
}


float VoxelGrid::get(int x, int y, int z) const {
    if (x >= 0 && x < width && y >= 0 && y < height && z >= 0 && z < depth) {
        return voxelGrid[y][x][z];
    }
    return 0.0f; // Outside bounds, return 0
}
std::vector<std::vector<std::vector<float>>>& VoxelGrid::getVoxelGrid() {
    return voxelGrid;
}
