#include "MarchingCubes.hpp"
#include "MarchingCubesTables.hpp" // edgeTable and triTable
#include <array>
#include <cmath>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>

static glm::vec3 vertexInterp(float isoLevel, const glm::vec3& p1, const glm::vec3& p2, float valp1, float valp2) noexcept {
    if (std::abs(isoLevel - valp1) < 0.00001f) return p1;
    if (std::abs(isoLevel - valp2) < 0.00001f) return p2;
    if (std::abs(valp1 - valp2) < 0.00001f) return p1;
    float mu = (isoLevel - valp1) / (valp2 - valp1);
    return p1 + mu * (p2 - p1);
}


// Function implementation must match the declaration in MarchingCubes.hpp
std::vector<Triangle> MarchingCubes::extractMesh(std::vector<std::vector<std::vector<float>>>& grid, float isoLevel) noexcept {
    std::vector<Triangle> triangles;

    // Return early if grid is malformed
    if (grid.empty() || grid[0].empty() || grid[0][0].empty())
        return triangles;

    const int edgeIndexPairs[12][2] = {
        {0,1}, {1,2}, {2,3}, {3,0},
        {4,5}, {5,6}, {6,7}, {7,4},
        {0,4}, {1,5}, {2,6}, {3,7}
    };

    int xSize = static_cast<int>(grid.size());
    int ySize = static_cast<int>(grid[0].size());
    int zSize = static_cast<int>(grid[0][0].size());

    for (int x = 0; x < xSize - 1; ++x) {
        for (int y = 0; y < ySize - 1; ++y) {
            for (int z = 0; z < zSize - 1; ++z) {
                glm::vec3 pos[8];
                float val[8];

                for (int i = 0; i < 8; ++i) {
                    int dx = i & 1;
                    int dy = (i >> 1) & 1;
                    int dz = (i >> 2) & 1;
                    pos[i] = glm::vec3(x + dx, y + dy, z + dz);
                    val[i] = grid[x + dx][y + dy][z + dz];
                }

                int cubeIndex = 0;
                for (int i = 0; i < 8; ++i)
                    if (val[i] < isoLevel)
                        cubeIndex |= (1 << i);

                int edges = edgeTable[cubeIndex];
                if (edges == 0) continue;

                glm::vec3 vertList[12] = {};

                for (int i = 0; i < 12; ++i) {
                    if (edges & (1 << i)) {
                        int a = edgeIndexPairs[i][0];
                        int b = edgeIndexPairs[i][1];
                        vertList[i] = vertexInterp(isoLevel, pos[a], pos[b], val[a], val[b]);
                    }
                }

                for (int i = 0; triTable[cubeIndex][i] != -1; i += 3) {
                    glm::vec3 v0 = vertList[triTable[cubeIndex][i]];
                    glm::vec3 v1 = vertList[triTable[cubeIndex][i + 1]];
                    glm::vec3 v2 = vertList[triTable[cubeIndex][i + 2]];

                    glm::vec3 normal = glm::normalize(glm::cross(v1 - v0, v2 - v0));

                    triangles.push_back({ {v0, normal}, {v1, normal}, {v2, normal} });
                }
            }
        }
    }

    return triangles;
}
