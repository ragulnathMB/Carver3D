﻿#pragma once

#include <vulkan/vulkan.h>
#include <vector>

class VulkanCommand {
public:
    VulkanCommand(VkDevice device,
        uint32_t queueFamilyIndex,
        VkRenderPass renderPass,
        VkExtent2D extent,
        const std::vector<VkFramebuffer>& framebuffers,
        VkPipeline pipeline,
        VkPipelineLayout pipelineLayout);

    ~VulkanCommand();

    const std::vector<VkCommandBuffer>& getCommandBuffers() const { return commandBuffers; }
    VkCommandBuffer getCommandBuffer(uint32_t index) const;

    void recordCommandBuffer(
        uint32_t imageIndex,
        VkBuffer vertexBuffer,
        VkBuffer indexBuffer,
        uint32_t indexCount,
        VkDescriptorSet descriptorSet);

private:
    VkDevice device;
    VkRenderPass renderPass;
    VkExtent2D extent;
    std::vector<VkFramebuffer> framebuffers;
    VkPipeline pipeline;
    VkPipelineLayout pipelineLayout;

    VkCommandPool commandPool = VK_NULL_HANDLE;
    std::vector<VkCommandBuffer> commandBuffers;

    void createCommandPool(uint32_t queueFamilyIndex);
    void allocateCommandBuffers(size_t count);
};
