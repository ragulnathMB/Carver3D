#include "UserInterface.hpp"
#include <stdexcept>
#include <fstream>

static float depthValue = 50.0f;

void UI::Init(GLFWwindow* window,
    VkInstance instance,
    VkPhysicalDevice physicalDevice,
    VkDevice device,
    uint32_t queueFamily,
    VkQueue queue,
    VkRenderPass renderPass,
    uint32_t imageCount,
    VkCommandBuffer fontUploadCmd)
{
    // 1. Create ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    ImGui::StyleColorsDark();

    // 2. Initialize platform/backend
    ImGui_ImplGlfw_InitForVulkan(window, true);

    // 3. Create descriptor pool for ImGui
    VkDescriptorPoolSize poolSizes[] = {
        { VK_DESCRIPTOR_TYPE_SAMPLER, 1000 },
        { VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 1000 },
        { VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE, 1000 },
        { VK_DESCRIPTOR_TYPE_STORAGE_IMAGE, 1000 },
        { VK_DESCRIPTOR_TYPE_UNIFORM_TEXEL_BUFFER, 1000 },
        { VK_DESCRIPTOR_TYPE_STORAGE_TEXEL_BUFFER, 1000 },
        { VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 1000 },
        { VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 1000 },
        { VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC, 1000 },
        { VK_DESCRIPTOR_TYPE_STORAGE_BUFFER_DYNAMIC, 1000 },
        { VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT, 1000 }
    };

    VkDescriptorPoolCreateInfo poolInfo{};
    poolInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
    poolInfo.flags = VK_DESCRIPTOR_POOL_CREATE_FREE_DESCRIPTOR_SET_BIT;
    poolInfo.maxSets = 1000;
    poolInfo.poolSizeCount = static_cast<uint32_t>(std::size(poolSizes));
    poolInfo.pPoolSizes = poolSizes;
    if (vkCreateDescriptorPool(device, &poolInfo, nullptr, &descriptorPool) != VK_SUCCESS) {
        throw std::runtime_error("Failed to create ImGui descriptor pool");
    }

    // 4. Initialize Vulkan renderer backend
    ImGui_ImplVulkan_InitInfo initInfo{};
    initInfo.Instance = instance;
    initInfo.PhysicalDevice = physicalDevice;
    initInfo.Device = device;
    initInfo.QueueFamily = queueFamily;
    initInfo.Queue = queue;
    initInfo.DescriptorPool = descriptorPool;
    initInfo.MinImageCount = 2;
    initInfo.ImageCount = imageCount;
    initInfo.MSAASamples = VK_SAMPLE_COUNT_1_BIT;
    initInfo.CheckVkResultFn = nullptr;
    ImGui_ImplVulkan_Init(&initInfo);

    // 5. Upload fonts using the provided command buffer
    ImGui_ImplVulkan_CreateFontsTexture(fontUploadCmd);
    // After submission and GPU execution of fontUploadCmd, cleanup upload objects:
    ImGui_ImplVulkan_DestroyFontUploadObjects();
}

void UI::BeginFrame() {
    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();
}

void UI::Render() {
    ImGui::Begin("2D to 3D Model Tool");

    ImGui::Text("Upload 2D projections:");
    if (ImGui::Button("Upload Front View")) {
        // TODO: open file dialog
    }
    if (ImGui::Button("Upload Side View")) {
        // TODO: open file dialog
    }

    ImGui::SliderFloat("Depth Guess", &depthValue, 0.0f, 100.0f);
    if (ImGui::Button("Generate 3D Model")) {
        std::ofstream out("settings.json");
        out << "{ \"depth\": " << depthValue << " }";
        // TODO: launch processing app
    }

    ImGui::End();
}

void UI::EndFrame(VkCommandBuffer cmdBuffer) {
    ImGui::Render();
    ImGui_ImplVulkan_RenderDrawData(ImGui::GetDrawData(), cmdBuffer);
}

void UI::Shutdown() {
    ImGui_ImplVulkan_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    // Optionally destroy descriptorPool
}
