﻿#pragma once

#include <vulkan/vulkan.h>
#include <vector>
#include <GLFW/glfw3.h>
#include "VulkanWindow.hpp"
#include "VulkanInstance.hpp"
#include "VulkanDevice.hpp"
#include "VulkanSwapchain.hpp"
#include "VulkanRenderPass.hpp"
#include "VulkanFramebuffer.hpp"
#include "VulkanPipeline.hpp"
#include "VulkanCommand.hpp"
#include "VulkanSync.hpp"
#include "VulkanBuffer.hpp"

// Forward declaration to avoid full include
class ImageProcessor;

constexpr uint32_t MAX_FRAMES_IN_FLIGHT = 2;

class VulkanContext {
public:
    VulkanContext(uint32_t width, uint32_t height, const char* title, ImageProcessor* processor);
    ~VulkanContext();

    void run();

private:
    void init(ImageProcessor* processor);
    void drawFrame();
    void cleanup();

    uint32_t width, height;
    const char* title;
    uint32_t currentFrame = 0;

    GLFWwindow* window;

    VulkanWindow* vulkanWindow;
    VulkanInstance* instance;
    VulkanDevice* device;
    VulkanSwapchain* swapchain;
    VulkanRenderPass* renderPass;
    VulkanFramebuffer* framebuffer;
    VulkanPipeline* pipeline;
    VulkanCommand* command;
    VulkanSync* sync;

    std::vector<VulkanBuffer*> uniformBuffers;
    VkDescriptorPool descriptorPool;
    std::vector<VkDescriptorSet> descriptorSets;

    VulkanBuffer* vertexBuffer;
    VulkanBuffer* indexBuffer;
    std::vector<uint32_t> indices;

    // Transform controls
    float zoomLevel = 2000.0f;
    float rotationAngleX = 0.0f;
    float rotationAngleY = 0.0f;
    float translateX = 0.0f;
    float translateY = 0.0f;
    float translateZ = 0.0f;
};
