#pragma once
#include <string>
#include <vector>
#include <opencv2/opencv.hpp>

struct ImageData {
    std::string url;
    float angleToRotateImageforCarving = 0.0f;
    float carvingDepthLimit = 1.0f;
    float carvingAngle = 0.0f;
    cv::Mat matrix;
};

class ImageProcessor {
private:
    int numberOfImages = 0;
   

public:
    void userInput();
    void setNumberOfImages(int number);
    void setImageData(const std::vector<ImageData>& data);
    float getImageLength() noexcept;
    float getImageWidth() noexcept;
    void processImages();
    std::string openFileDialog();
    std::vector<ImageData> imagesData;
};
