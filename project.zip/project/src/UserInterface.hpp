#pragma once

#include <GLFW/glfw3.h>
#include <vulkan/vulkan.h>
#include <imgui.h>
#include <imgui_impl_glfw.h>
#include <imgui_impl_vulkan.h>
// Manual extern declarations for font upload helpers
extern void ImGui_ImplVulkan_CreateFontsTexture(VkCommandBuffer command_buffer);
extern void ImGui_ImplVulkan_DestroyFontUploadObjects();
struct UserInput {
    int numberOfImages = 0;
    std::string frontImagePath;
    std::string sideImagePath;
    std::string topImagePath;
    float depthValue = 50.0f;
};
class UI {
public:
    // Initialize ImGui (call once after window/context setup)
    // Requires a command buffer to upload fonts (one-time)
    void Init(GLFWwindow* window,
        VkInstance instance,
        VkPhysicalDevice physicalDevice,
        VkDevice device,
        uint32_t queueFamily,
        VkQueue queue,
        VkRenderPass renderPass,
        uint32_t imageCount,
        VkCommandBuffer fontUploadCmd);

    // Begin ImGui frame (call at start of each frame)
    void BeginFrame();

    // Render your custom ImGui UI (call between NewFrame() and EndFrame())
    void Render(UserInput& input, bool& shouldClose);

    // End ImGui frame and draw (call after Render)
    void EndFrame(VkCommandBuffer cmdBuffer);

    // Cleanup ImGui (call on exit)
    void Shutdown();

private:
    VkDescriptorPool descriptorPool = VK_NULL_HANDLE;
};