﻿#define NOMINMAX

#include "ImageProcessor.hpp"
#include <windows.h>
#include <commdlg.h>
#include <limits>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <filesystem>
#include<algorithm>

#undef max // Prevent Windows macro collision with std::max

// Globals for OpenCV flood fill
static cv::Mat currentMask;
static bool regionSelected = false;

// Mouse callback for flood fill
static void onMouse(int event, int x, int y, int, void*) {
    if (event != cv::EVENT_LBUTTONDOWN) return;

    cv::Scalar fillColor = cv::Scalar(0);  // Fill with gray
    cv::Scalar loDiff = 5, upDiff = 5;
    int flags = 4 | cv::FLOODFILL_FIXED_RANGE;

    cv::floodFill(currentMask, cv::Point(x, y), fillColor, nullptr, loDiff, upDiff, flags);
    cv::imshow("Click regions to remove (press 'x' to finish)", currentMask);
}

// File dialog for selecting image
std::string ImageProcessor::openFileDialog() {
    OPENFILENAMEW ofn;
    wchar_t szFile[MAX_PATH] = { 0 };

    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = nullptr;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"Image Files\0*.jpg;*.jpeg;*.png;*.bmp\0All Files\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

    if (GetOpenFileNameW(&ofn)) {
        int size = WideCharToMultiByte(CP_UTF8, 0, szFile, -1, nullptr, 0, nullptr, nullptr);
        std::string result(size, 0);
        WideCharToMultiByte(CP_UTF8, 0, szFile, -1, &result[0], size, nullptr, nullptr);
        result.pop_back(); // remove null terminator
        return result;
    }

    return {};
}

// Main user input loop
void ImageProcessor::userInput() {
    // Backup current working directory to prevent shader loading issues
    const std::filesystem::path originalCWD = std::filesystem::current_path();

    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    imagesData.clear();

    for (int i = 0; i < numberOfImages; ++i) {
        std::cout << "\n[Input] Select image " << i + 1 << " from dialog box...\n";
        std::string path = openFileDialog();
        if (path.empty()) {
            std::cerr << "[Error] File selection cancelled.\n";
            continue;
        }

        cv::Mat rawInput = cv::imread(path, cv::IMREAD_GRAYSCALE);
        cv::resize(rawInput, rawInput, cv::Size(256, 256), 0, 0, cv::INTER_AREA);
        if (rawInput.empty()) {
            std::cerr << "[Error] Could not load image: " << path << "\n";
            continue;
        }

        ImageData data;
        data.url = path;
        data.angleToRotateImageforCarving = 0.0f;
        data.carvingDepthLimit = 1.0f;
        data.carvingAngle = 0.0f;

        std::cout << "Enter rotation angle (degrees): ";
        std::cin >> data.angleToRotateImageforCarving;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        std::cout << "Enter carving depth limit (e.g., 1.0): ";
        std::cin >> data.carvingDepthLimit;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        std::cout << "Enter carving angle (e.g., 0.0): ";
        std::cin >> data.carvingAngle;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        // --- Interactive mask selection
        currentMask = rawInput.clone();
        regionSelected = false;

        std::cout << "[Info] Click on background regions to remove.\n";
        std::cout << "[Info] Use W/A/S/D to scroll if image is large.\n";
        std::cout << "[Info] Press 'x' when done.\n";

        cv::namedWindow("Click regions to remove (press 'x' to finish)", cv::WINDOW_AUTOSIZE);
        cv::setMouseCallback("Click regions to remove (press 'x' to finish)", onMouse);

        // Scrollable view parameters
        cv::Rect viewROI(0, 0, std::min(800, currentMask.cols), std::min(600, currentMask.rows));

        while (true) {
            cv::Mat view = currentMask(viewROI);
            cv::imshow("Click regions to remove (press 'x' to finish)", view);
            int key = cv::waitKey(0);

            if (key == 'x' || key == 'X') break;
            else if (key == 'w') viewROI.y = std::max(viewROI.y - 20, 0);
            else if (key == 's') viewROI.y = std::min(viewROI.y + 20, currentMask.rows - viewROI.height);
            else if (key == 'a') viewROI.x = std::max(viewROI.x - 20, 0);
            else if (key == 'd') viewROI.x = std::min(viewROI.x + 20, currentMask.cols - viewROI.width);
        }

        // Convert to binary mask: gray (128) becomes 0, white (255) becomes 1
        cv::Mat binaryMask;
        cv::threshold(currentMask, binaryMask, 127, 1, cv::THRESH_BINARY);
        data.matrix = binaryMask.clone();  // 0 = to carve, 1 = solid

        imagesData.push_back(data);

        cv::destroyWindow("Click regions to remove (press 'x' to finish)");
        std::cout << "[OK] Finished processing image " << i + 1 << ".\n";
    }

    // Restore working directory to fix shader loading
    std::filesystem::current_path(originalCWD);
}

void ImageProcessor::setNumberOfImages(int number) {
    numberOfImages = number;
}

void ImageProcessor::setImageData(const std::vector<ImageData>& data) {
    imagesData = data;
}

float ImageProcessor::getImageLength() noexcept {
    return (!imagesData.empty()) ? static_cast<float>(imagesData[0].matrix.cols) : 0.0f;
}

float ImageProcessor::getImageWidth() noexcept {
    return (!imagesData.empty()) ? static_cast<float>(imagesData[0].matrix.rows) : 0.0f;
}

void ImageProcessor::processImages() {
    for (auto& image : imagesData) {
        if (image.angleToRotateImageforCarving != 0.0f) {
            cv::Point2f center(image.matrix.cols / 2.0f, image.matrix.rows / 2.0f);
            cv::Mat rotMat = cv::getRotationMatrix2D(center, image.angleToRotateImageforCarving, 1.0);
            cv::warpAffine(image.matrix, image.matrix, rotMat, image.matrix.size());
        }
    }
}
