﻿#include "VulkanContext.hpp"
#include "Input.hpp"
#include "Utils.hpp"
#include <stdexcept>
#include <iostream>
#include <glm/gtc/matrix_transform.hpp>
#include<vector>
#include "VoxelGrid.hpp"
#include "MarchingCubes.hpp"
#include "ImageProcessor.hpp"


struct MVP {
    glm::mat4 model;
    glm::mat4 view;
    glm::mat4 proj;
};

VulkanContext::VulkanContext(uint32_t w, uint32_t h, const char* t, ImageProcessor* processor)
    : width(w), height(h), title(t),
    instance(nullptr), vulkanWindow(nullptr), device(nullptr),
    swapchain(nullptr), renderPass(nullptr), framebuffer(nullptr),
    pipeline(nullptr), command(nullptr), sync(nullptr),
    vertexBuffer(nullptr), indexBuffer(nullptr), descriptorPool(VK_NULL_HANDLE),
    currentFrame(0), zoomLevel(3.5f), rotationAngleX(0.0f), rotationAngleY(0.0f),
    translateX(0.0f), translateY(0.0f), translateZ(0.0f)
{
    init(processor);
}

VulkanContext::~VulkanContext() {
    cleanup();
}



void VulkanContext::init(ImageProcessor* imageProcessor) {
    LOG_INFO("Initializing Vulkan Context...");

    vulkanWindow = new VulkanWindow(width, height, title);
    window = vulkanWindow->getGLFWWindow();
    Input::init(window);

    instance = new VulkanInstance(true);
    vulkanWindow->createAndGetSurface(instance->getInstance());

    float len = imageProcessor->getImageLength();
    VoxelGrid* voxelGrid = new VoxelGrid(len, len, len);
    voxelGrid->setVoxel(
        imageProcessor->imagesData[0].matrix,
        imageProcessor->imagesData[1].matrix,
        imageProcessor->imagesData[2].matrix
    );

    std::vector<Triangle> triangles = MarchingCubes::extractMesh(voxelGrid->getVoxelGrid(), 0.50f);
    std::vector<Vertex> vertices;
    indices.clear();
    uint32_t index = 0;
    for (const auto& tri : triangles) {
        vertices.push_back(tri.v0);
        vertices.push_back(tri.v1);
        vertices.push_back(tri.v2);
        indices.push_back(index++);
        indices.push_back(index++);
        indices.push_back(index++);
    }

    device = new VulkanDevice(instance->getInstance(), vulkanWindow->getSurface());
    swapchain = new VulkanSwapchain(device->getPhysicalDevice(), device->getDevice(), vulkanWindow->getSurface(), width, height);
    renderPass = new VulkanRenderPass(device->getDevice(), swapchain->getImageFormat());
    framebuffer = new VulkanFramebuffer(device->getDevice(), renderPass->get(), swapchain->getImageViews(), swapchain->getExtent());
    pipeline = new VulkanPipeline(device->getDevice(), swapchain->getExtent(), renderPass->get(), "vert.spv", "frag.spv");

    VkDeviceSize bufferSize = sizeof(MVP);
    uniformBuffers.resize(MAX_FRAMES_IN_FLIGHT);
    for (size_t i = 0; i < MAX_FRAMES_IN_FLIGHT; ++i) {
        uniformBuffers[i] = new VulkanBuffer(
            device->getDevice(),
            device->getPhysicalDevice(),
            bufferSize,
            VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
            VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT
        );
    }

    vertexBuffer = new VulkanBuffer(
        device->getDevice(), device->getPhysicalDevice(),
        sizeof(Vertex) * vertices.size(),
        VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT
    );
    vertexBuffer->copyData(vertices.data(), sizeof(Vertex) * vertices.size());

    indexBuffer = new VulkanBuffer(
        device->getDevice(), device->getPhysicalDevice(),
        sizeof(uint32_t) * indices.size(),
        VK_BUFFER_USAGE_INDEX_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT
    );
    indexBuffer->copyData(indices.data(), sizeof(uint32_t) * indices.size());

    VkDescriptorPoolSize poolSize{};
    poolSize.type = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    poolSize.descriptorCount = static_cast<uint32_t>(MAX_FRAMES_IN_FLIGHT);

    VkDescriptorPoolCreateInfo poolInfo{};
    poolInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
    poolInfo.poolSizeCount = 1;
    poolInfo.pPoolSizes = &poolSize;
    poolInfo.maxSets = MAX_FRAMES_IN_FLIGHT;
    VK_CHECK(vkCreateDescriptorPool(device->getDevice(), &poolInfo, nullptr, &descriptorPool));

    std::vector<VkDescriptorSetLayout> layouts(MAX_FRAMES_IN_FLIGHT, pipeline->getDescriptorSetLayout());

    VkDescriptorSetAllocateInfo allocInfo{};
    allocInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
    allocInfo.descriptorPool = descriptorPool;
    allocInfo.descriptorSetCount = MAX_FRAMES_IN_FLIGHT;
    allocInfo.pSetLayouts = layouts.data();

    descriptorSets.resize(MAX_FRAMES_IN_FLIGHT);
    VK_CHECK(vkAllocateDescriptorSets(device->getDevice(), &allocInfo, descriptorSets.data()));

    for (size_t i = 0; i < MAX_FRAMES_IN_FLIGHT; ++i) {
        VkDescriptorBufferInfo bufferInfo{};
        bufferInfo.buffer = uniformBuffers[i]->getBuffer();
        bufferInfo.offset = 0;
        bufferInfo.range = sizeof(MVP);

        VkWriteDescriptorSet descriptorWrite{};
        descriptorWrite.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
        descriptorWrite.dstSet = descriptorSets[i];
        descriptorWrite.dstBinding = 0;
        descriptorWrite.dstArrayElement = 0;
        descriptorWrite.descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
        descriptorWrite.descriptorCount = 1;
        descriptorWrite.pBufferInfo = &bufferInfo;

        vkUpdateDescriptorSets(device->getDevice(), 1, &descriptorWrite, 0, nullptr);
    }

    command = new VulkanCommand(
        device->getDevice(),
        device->getGraphicsQueueFamilyIndex(),
        renderPass->get(),
        swapchain->getExtent(),
        framebuffer->getFramebuffers(),
        pipeline->get(),
        pipeline->getLayout()
    );

    sync = new VulkanSync(device->getDevice(), MAX_FRAMES_IN_FLIGHT);

    LOG_INFO("Vulkan Context Initialized.");
}


void VulkanContext::run() {
    while (!vulkanWindow->shouldClose()) {
        vulkanWindow->pollEvents();
        Input::pollEvents();
        drawFrame();
    }

    vkDeviceWaitIdle(device->getDevice());
}

void VulkanContext::drawFrame() {
    size_t frameIndex = currentFrame;

    sync->waitForFrame(frameIndex);

    uint32_t imageIndex;
    VkResult result = vkAcquireNextImageKHR(
        device->getDevice(),
        swapchain->getSwapchain(),
        UINT64_MAX,
        sync->getImageAvailableSemaphore(frameIndex),
        VK_NULL_HANDLE,
        &imageIndex
    );

    if (result == VK_ERROR_OUT_OF_DATE_KHR) {
        LOG_WARN("Swapchain out of date — skipping frame.");
        return;
    }

    sync->resetFence(frameIndex);
    // dynamic keys
    if (Input::isKeyPressed(GLFW_KEY_W)) {
        zoomLevel -= 1.0f;
        std::cout << "Zoom In: " << zoomLevel << "\n";
    }
    if (Input::isKeyPressed(GLFW_KEY_S)) {
        zoomLevel += 1.0f;
        std::cout << "Zoom Out: " << zoomLevel << "\n";
    }
    if (Input::isKeyPressed(GLFW_KEY_LEFT)) {
        rotationAngleX -= 0.01f;
        std::cout << "Rot Left: " << rotationAngleX << "\n";
    }
    if (Input::isKeyPressed(GLFW_KEY_RIGHT)) {
        rotationAngleX += 0.01f;
        std::cout << "Rot Right: " << rotationAngleX << "\n";
    }
    if(Input::isKeyPressed(GLFW_KEY_UP)) {
		rotationAngleY += 0.01f;
		std::cout << "Rot Up: " << rotationAngleY << "\n";
	}
    if (Input::isKeyPressed(GLFW_KEY_DOWN)) {
		rotationAngleY -= 0.01f;
		std::cout << "Rot Down: " << rotationAngleY << "\n";
    }
    if (Input::isKeyPressed(GLFW_KEY_I)) {
		translateY += 1.0f;
		std::cout << "Translate Y: " << translateY << "\n";
    }
    if (Input::isKeyPressed(GLFW_KEY_K)) {
        translateY -= 1.0f;
        std::cout << "Translate Y: " << translateY << "\n";
    }
    if (Input::isKeyPressed(GLFW_KEY_J)) {
        translateX -= 1.0f;
        std::cout << "Translate X: " << translateX << "\n";
    }
    if (Input::isKeyPressed(GLFW_KEY_L)) {
        translateX += 1.0f;
        std::cout << "Translate X: " << translateX << "\n";
    }

    

    // Update MVP (basic identity for voxel render)
    MVP mvp{};

    // View Matrix - camera looking at center
    glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, zoomLevel);
    mvp.view = glm::lookAt(
        cameraPos,                     // Camera position
        glm::vec3(0.0f, 0.0f, 0.0f),   // Look at origin
        glm::vec3(0.0f, 1.0f, 0.0f)    // Up vector
    );

    // Projection Matrix - flipped for Vulkan
    mvp.proj = glm::perspective(glm::radians(45.0f), width / (float)height, 0.1f, 2000.0f);
    mvp.proj[1][1] *= -1.0f;  // Vulkan coordinate fix

    // Model Matrix - apply transformations in correct order
    mvp.model = glm::mat4(1.0f);
    mvp.model = glm::translate(mvp.model, glm::vec3(-128.0f, -128.0f, -128.0f));  // Center model
    mvp.model = glm::translate(mvp.model, glm::vec3(translateX, translateY, translateZ)); // Optional movement
    mvp.model = glm::rotate(mvp.model, rotationAngleX, glm::vec3(0, 1, 0)); // Rotate Y
    mvp.model = glm::rotate(mvp.model, rotationAngleY, glm::vec3(1, 0, 0)); // Rotate X





    uniformBuffers[frameIndex]->copyData(&mvp, sizeof(MVP));

    // Record draw
    command->recordCommandBuffer(
        imageIndex,
        vertexBuffer->getBuffer(),
        indexBuffer->getBuffer(),
        static_cast<uint32_t>(indices.size()),
        descriptorSets[frameIndex]
    );


    // Submit
    VkSubmitInfo submitInfo{};
    submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;

    VkSemaphore waitSemaphores[] = { sync->getImageAvailableSemaphore(frameIndex) };
    VkPipelineStageFlags waitStages[] = { VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT };
    submitInfo.waitSemaphoreCount = 1;
    submitInfo.pWaitSemaphores = waitSemaphores;
    submitInfo.pWaitDstStageMask = waitStages;

    VkCommandBuffer cmd = command->getCommandBuffer(imageIndex);
    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &cmd;

    VkSemaphore signalSemaphores[] = { sync->getRenderFinishedSemaphore(frameIndex) };
    submitInfo.signalSemaphoreCount = 1;
    submitInfo.pSignalSemaphores = signalSemaphores;

    VK_CHECK(vkQueueSubmit(device->getGraphicsQueue(), 1, &submitInfo, sync->getInFlightFence(frameIndex)));

    // Present
    VkPresentInfoKHR presentInfo{};
    presentInfo.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
    presentInfo.waitSemaphoreCount = 1;
    presentInfo.pWaitSemaphores = signalSemaphores;
    VkSwapchainKHR swapchains[] = { swapchain->getSwapchain() };
    presentInfo.swapchainCount = 1;
    presentInfo.pSwapchains = swapchains;
    presentInfo.pImageIndices = &imageIndex;

    result = vkQueuePresentKHR(device->getPresentQueue(), &presentInfo);
    if (result == VK_ERROR_OUT_OF_DATE_KHR || result == VK_SUBOPTIMAL_KHR) {
        LOG_WARN("Swapchain suboptimal or outdated — recreate needed");
    }

    currentFrame = (currentFrame + 1) % MAX_FRAMES_IN_FLIGHT;
}

void VulkanContext::cleanup() {
    LOG_INFO("Cleaning up...");
    vkDeviceWaitIdle(device->getDevice());

    for (auto buf : uniformBuffers)
        delete buf;
    

    delete vertexBuffer;
    delete indexBuffer;

    vkDestroyDescriptorPool(device->getDevice(), descriptorPool, nullptr);

    delete sync;
    delete command;
    delete pipeline;
    delete framebuffer;
    delete renderPass;
    delete swapchain;
    delete device;

    vkDestroySurfaceKHR(instance->getInstance(), vulkanWindow->getSurface(), nullptr);

    delete vulkanWindow;
    delete instance;

    glfwTerminate();
}
