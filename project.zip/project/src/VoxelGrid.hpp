#pragma once  
#include <vector>  
#include <float.h>  
#include <opencv2/opencv.hpp> // Include OpenCV header for cv::Mat  

class VoxelGrid {  
public:  
    unsigned int width, height, depth;  
    VoxelGrid(float h, float w, float d);  
    ~VoxelGrid();  
    void setVoxel(const cv::Mat& frontView,const cv::Mat& sideView ,const cv::Mat& topView); // Ensure cv::Mat is recognized  
    float get(int x, int y, int z) const;
    std::vector<std::vector<std::vector<float>>>& getVoxelGrid();
    

private:  
    std::vector<std::vector<std::vector<float>>> voxelGrid;  

};