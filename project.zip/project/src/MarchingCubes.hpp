#pragma once

#include <vector>
#include <glm/glm.hpp>
#include "VoxelGrid.hpp"

struct Vertex {
    glm::vec3 position;
    glm::vec3 normal;
};

struct Triangle {
    Vertex v0, v1, v2;
};

class MarchingCubes {
public:
    static std::vector<Triangle> extractMesh(std::vector<std::vector<std::vector<float>>>& grid, float isoLevel = 0.5f) noexcept;
};
